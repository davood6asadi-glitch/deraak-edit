/**
 * Deraak RFQ (Request For Quotation) Cart Manager
 */

(function () {
  'use strict';

  var RFQ_KEY = 'derak_rfq_items';

  function getRFQItems() {
    try {
      return JSON.parse(localStorage.getItem(RFQ_KEY) || '[]');
    } catch (e) {
      return [];
    }
  }

  function saveRFQItems(items) {
    try {
      localStorage.setItem(RFQ_KEY, JSON.stringify(items));
    } catch (e) {}
    updateDockBadge();
  }

  function updateDockBadge() {
    var items = getRFQItems();
    var count = items.reduce(function (sum, item) {
      return sum + (item.quantity || 1);
    }, 0);

    var badge = document.getElementById('derak-rfq-count-badge');
    if (badge) {
      if (count > 0) {
        badge.textContent = count;
        badge.style.display = 'flex';
      } else {
        badge.style.display = 'none';
      }
    }
  }

  // Listen for Add to RFQ custom event
  window.addEventListener('derak_add_to_rfq', function (e) {
    var detail = e.detail;
    if (!detail || !detail.id) return;

    var items = getRFQItems();
    var existing = items.find(function (item) { return item.id === detail.id; });

    if (existing) {
      existing.quantity = (existing.quantity || 1) + 1;
    } else {
      items.push({
        id: detail.id,
        title: detail.title,
        model: detail.model,
        quantity: 1,
        notes: '',
        urgent: false
      });
    }

    saveRFQItems(items);
    renderRFQTable();
  });

  // Render RFQ Page Table
  function renderRFQTable() {
    var list = document.getElementById('derak-rfq-items-list');
    var empty = document.getElementById('derak-rfq-empty');
    var content = document.getElementById('derak-rfq-content');

    if (!list) return;

    var items = getRFQItems();

    if (items.length === 0) {
      if (empty) empty.style.display = 'block';
      if (content) content.style.display = 'none';
      return;
    }

    if (empty) empty.style.display = 'none';
    if (content) content.style.display = 'block';

    list.innerHTML = '';

    items.forEach(function (item, idx) {
      var row = document.createElement('div');
      row.style.display = 'flex';
      row.style.alignItems = 'center';
      row.style.justifyContent = 'space-between';
      row.style.padding = '12px';
      row.style.border = '1px solid #DEDCD6';
      row.style.borderRadius = '8px';
      row.style.backgroundColor = item.urgent ? '#FFF8E1' : '#FFFFFF';
      row.style.gap = '12px';

      row.innerHTML = 
        '<div style="flex:1;">' +
          '<div style="display:flex; align-items:center; gap:8px;">' +
            '<span style="font-weight:bold; color:#031A54; font-size:14px;">' + (idx + 1) + '. ' + item.title + '</span>' +
            (item.model ? '<span class="derak-card-model" style="margin:0;" dir="ltr">' + item.model + '</span>' : '') +
            (item.urgent ? '<span style="font-size:10px; background:#BA1A1A; color:#fff; padding:2px 6px; border-radius:4px;">فوری / توقف خط</span>' : '') +
          '</div>' +
          '<input type="text" placeholder="یادداشت فنی / متریال دیافراگم / گواهی تست..." value="' + (item.notes || '') + '" data-id="' + item.id + '" class="derak-rfq-note" style="width:100%; height:32px; font-size:12px; margin-top:6px; border:1px solid #DEDCD6; border-radius:4px; padding:0 8px;" />' +
        '</div>' +

        '<div style="display:flex; align-items:center; gap:8px;">' +
          '<div style="display:flex; align-items:center; border:1px solid #DEDCD6; border-radius:6px; overflow:hidden;">' +
            '<button type="button" class="derak-qty-btn" data-id="' + item.id + '" data-delta="-1" style="width:30px; height:30px; border:none; background:#EEF0FF; cursor:pointer;">-</button>' +
            '<span style="width:36px; text-align:center; font-family:var(--derak-font-mono); font-weight:bold;">' + item.quantity + '</span>' +
            '<button type="button" class="derak-qty-btn" data-id="' + item.id + '" data-delta="1" style="width:30px; height:30px; border:none; background:#EEF0FF; cursor:pointer;">+</button>' +
          '</div>' +

          '<button type="button" class="derak-urgent-btn" data-id="' + item.id + '" title="علامت‌گذاری فوریت توقف خط" style="border:1px solid #DEDCD6; background:#fff; border-radius:6px; height:30px; padding:0 8px; font-size:11px; cursor:pointer;">' +
            (item.urgent ? 'عادی‌سازی' : '⚠️ فوری') +
          '</button>' +

          '<button type="button" class="derak-remove-rfq-btn" data-id="' + item.id + '" style="border:none; background:none; color:#BA1A1A; cursor:pointer; font-size:16px;">✕</button>' +
        '</div>';

      list.appendChild(row);
    });
  }

  // Delegated clicks for RFQ controls
  document.addEventListener('click', function (e) {
    var target = e.target;

    // Quantity buttons
    if (target.classList.contains('derak-qty-btn')) {
      var id = target.getAttribute('data-id');
      var delta = parseInt(target.getAttribute('data-delta'), 10);
      var items = getRFQItems();
      var item = items.find(function (it) { return it.id === id; });
      if (item) {
        item.quantity += delta;
        if (item.quantity <= 0) {
          items = items.filter(function (it) { return it.id !== id; });
        }
        saveRFQItems(items);
        renderRFQTable();
      }
    }

    // Remove single item
    if (target.classList.contains('derak-remove-rfq-btn')) {
      var rmId = target.getAttribute('data-id');
      var updated = getRFQItems().filter(function (it) { return it.id !== rmId; });
      saveRFQItems(updated);
      renderRFQTable();
    }

    // Toggle urgency
    if (target.classList.contains('derak-urgent-btn')) {
      var urgId = target.getAttribute('data-id');
      var list = getRFQItems();
      var found = list.find(function (it) { return it.id === urgId; });
      if (found) {
        found.urgent = !found.urgent;
        saveRFQItems(list);
        renderRFQTable();
      }
    }

    // Clear All
    if (target.id === 'derak-rfq-clear-btn') {
      if (confirm('آیا از پاکسازی کل لیست استعلام اطمینان دارید؟')) {
        saveRFQItems([]);
        renderRFQTable();
      }
    }

    // Copy text
    if (target.closest('#derak-rfq-copy-btn')) {
      var txt = generateRFQReportText();
      navigator.clipboard.writeText(txt).then(function () {
        alert('متن رسمی پیش‌فاکتور استعلام در کلیپ‌بورد کپی گردید.');
      });
    }

    // WhatsApp Send
    if (target.closest('#derak-rfq-wa-btn')) {
      var waTxt = generateRFQReportText();
      var phone = '989120000000'; // Default, or read from theme
      var waUrl = 'https://api.whatsapp.com/send?phone=' + phone + '&text=' + encodeURIComponent(waTxt);
      window.open(waUrl, '_blank');
    }
  });

  // Note change handler
  document.addEventListener('input', function (e) {
    if (e.target.classList.contains('derak-rfq-note')) {
      var nId = e.target.getAttribute('data-id');
      var nVal = e.target.value;
      var items = getRFQItems();
      var item = items.find(function (it) { return it.id === nId; });
      if (item) {
        item.notes = nVal;
        saveRFQItems(items);
      }
    }
  });

  function generateRFQReportText() {
    var siteEl = document.getElementById('derak-rfq-site');
    var compEl = document.getElementById('derak-rfq-company');
    var phoneEl = document.getElementById('derak-rfq-phone');

    var site = siteEl ? siteEl.value : 'اعلام نشده';
    var comp = compEl ? compEl.value : 'اعلام نشده';
    var phone = phoneEl ? phoneEl.value : 'اعلام نشده';

    var items = getRFQItems();
    var output = 'استعلام رسمی قیمت و موجودی کالا - دراک ابزار دقیق (add.co.ir)\n';
    output += 'سایت پروژه / تحویل: ' + site + '\n';
    output += 'نام شرکت / پروژه: ' + comp + '\n';
    output += 'شماره تماس خریدار: ' + phone + '\n\n';
    output += 'اقلام درخواستی:\n';

    items.forEach(function (it, idx) {
      output += (idx + 1) + '. مدل: ' + (it.model || 'نامشخص') + ' | ' + it.title + '\n';
      output += '   تعداد: ' + it.quantity + ' عدد\n';
      if (it.notes) output += '   مشخصات/یادداشت: ' + it.notes + '\n';
      if (it.urgent) output += '   وضعیت فوریت: توقف خط / بحرانی\n';
    });

    output += '\nدرخواست ارسال پیش‌فاکتور رسمی و زمان تحویل به انبار تهران یا سایت پروژه.';
    return output;
  }

  document.addEventListener('DOMContentLoaded', function () {
    updateDockBadge();
    renderRFQTable();
  });

})();
