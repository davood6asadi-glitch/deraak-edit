/**
 * Deraak IndexedDB Catalog Engine & Recently Viewed Handler
 */

(function () {
  'use strict';

  var DB_NAME = 'derak_catalog_db';
  var DB_VERSION = 1;
  var STORE_NAME = 'products';
  var dbInstance = null;

  function openDatabase(callback) {
    if (dbInstance) {
      return callback(null, dbInstance);
    }

    if (!('indexedDB' in window)) {
      return callback('IndexedDB is not supported');
    }

    var request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = function (e) {
      var db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        var store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('sku', 'sku', { unique: false });
        store.createIndex('brand', 'brand', { unique: false });
      }
    };

    request.onsuccess = function (e) {
      dbInstance = e.target.result;
      callback(null, dbInstance);
    };

    request.onerror = function (e) {
      callback(e.target.error);
    };
  }

  window.DeraakCatalogDB = {
    syncWithServer: function (callback) {
      if (!window.deraakPWA || !window.deraakPWA.catalogApi) {
        if (callback) callback(false, 0);
        return;
      }

      fetch(window.deraakPWA.catalogApi)
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (!data || !Array.isArray(data.items)) {
            if (callback) callback(false, 0);
            return;
          }

          openDatabase(function (err, db) {
            if (err) {
              if (callback) callback(false, 0);
              return;
            }

            var tx = db.transaction(STORE_NAME, 'readwrite');
            var store = tx.objectStore(STORE_NAME);

            data.items.forEach(function (item) {
              store.put(item);
            });

            tx.oncomplete = function () {
              localStorage.setItem('derak_catalog_last_sync', Date.now().toString());
              if (callback) callback(true, data.items.length);
            };

            tx.onerror = function () {
              if (callback) callback(false, 0);
            };
          });
        })
        .catch(function () {
          if (callback) callback(false, 0);
        });
    },

    getProduct: function (id, callback) {
      openDatabase(function (err, db) {
        if (err) return callback(null);
        var tx = db.transaction(STORE_NAME, 'readonly');
        var store = tx.objectStore(STORE_NAME);
        var req = store.get(id);
        req.onsuccess = function () {
          callback(req.result);
        };
        req.onerror = function () {
          callback(null);
        };
      });
    }
  };

  // Auto-sync catalog in background if older than 24 hours
  var lastSync = localStorage.getItem('derak_catalog_last_sync');
  if (!lastSync || (Date.now() - parseInt(lastSync, 10)) > (24 * 60 * 60 * 1000)) {
    if (navigator.onLine) {
      setTimeout(function () {
        window.DeraakCatalogDB.syncWithServer();
      }, 2500);
    }
  }

  // 2. Recently Viewed Products Widget Renderer
  function renderRecentlyViewed() {
    var container = document.getElementById('derak-recent-container');
    var emptyState = document.getElementById('derak-recent-empty');
    var badge = document.getElementById('derak-recent-badge');
    var clearBtn = document.getElementById('derak-clear-recent-btn');

    if (!container) return;

    var recentIds = [];
    try {
      recentIds = JSON.parse(localStorage.getItem('derak_recently_viewed') || '[]');
    } catch (e) {
      recentIds = [];
    }

    if (!recentIds || recentIds.length === 0) {
      container.innerHTML = '';
      if (emptyState) emptyState.style.display = 'block';
      if (badge) badge.style.display = 'none';
      if (clearBtn) clearBtn.style.display = 'none';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';
    if (badge) {
      badge.textContent = recentIds.length + ' مورد';
      badge.style.display = 'inline-block';
    }
    if (clearBtn) clearBtn.style.display = 'inline-block';

    container.innerHTML = '';
    recentIds.forEach(function (id) {
      window.DeraakCatalogDB.getProduct(id, function (product) {
        if (!product) return;

        var card = document.createElement('article');
        card.className = 'derak-product-card';
        card.style.minWidth = '260px';
        card.style.maxWidth = '270px';
        card.style.flexShrink = '0';

        card.innerHTML = 
          '<div class="derak-card-top">' +
            '<span class="derak-card-brand" dir="ltr">' + (product.brand || '') + '</span>' +
            '<span class="derak-card-badge">' + (product.statusBadge || 'موجود') + '</span>' +
          '</div>' +
          '<a href="' + (product.permalink || '#') + '" class="derak-card-media">' +
            '<img src="' + (product.image || '') + '" class="derak-card-img" alt="' + product.title + '">' +
            '<span class="derak-card-tag" dir="ltr">' + (product.tag || 'INDUSTRIAL') + '</span>' +
          '</a>' +
          '<a href="' + (product.permalink || '#') + '" class="derak-card-title">' + product.title + '</a>' +
          '<div><span class="derak-card-model" dir="ltr">' + (product.sku || '') + '</span></div>' +
          '<div class="derak-param-matrix">' +
            '<span class="derak-param-label">' + (product.param1.label || '') + '</span>' +
            '<span class="derak-param-val" dir="ltr">' + (product.param1.value || '') + '</span>' +
            '<span class="derak-param-label">' + (product.param2.label || '') + '</span>' +
            '<span class="derak-param-val" dir="ltr">' + (product.param2.value || '') + '</span>' +
          '</div>' +
          '<div class="derak-card-actions">' +
            '<button type="button" class="derak-btn-icon-add" data-product-id="' + product.id + '" data-product-title="' + product.title + '" data-product-model="' + product.sku + '">+</button>' +
            '<a href="' + (product.permalink || '#') + '" class="derak-btn-card-detail">مشاهده دیتاشیت</a>' +
          '</div>';

        container.appendChild(card);
      });
    });
  }

  document.addEventListener('DOMContentLoaded', renderRecentlyViewed);

  // Clear button
  document.addEventListener('click', function (e) {
    if (e.target && e.target.id === 'derak-clear-recent-btn') {
      localStorage.removeItem('derak_recently_viewed');
      renderRecentlyViewed();
    }
  });

})();
